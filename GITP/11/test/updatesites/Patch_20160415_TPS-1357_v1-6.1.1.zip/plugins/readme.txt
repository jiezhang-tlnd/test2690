Patch_20160415_TPS-1357_v1.zip

Fixed JIRA ticket(s):

****************2016-04-15*******************
TPS-1357:[6.1.1] 'activate query logging' checked by default for upgraded jobs (TDI-35645)(zhaojin, wangwei)
