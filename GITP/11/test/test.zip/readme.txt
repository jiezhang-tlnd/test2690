Patch Readme:
(1) Fixed JIRA ticket(s): XXXX. 
(2) Prerequisites: none
(3) Installation Steps:
    a. Shut down Talend studio if it is opened.
    b. Extract the zip.
    c. Merge the folder "plugins" and its content to {studio}/plugins and overwrite the existing files.
    d. Restart the Talend studio
(4) Post-installation steps: none
    
